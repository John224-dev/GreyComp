from flask import Flask, render_template, request, flash, redirect, url_for
import os
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/subscribe', methods=['POST'])
def subscribe():
    if request.method == 'POST':
        email = request.form.get('email')
        if email:
            logger.info(f"New newsletter subscription request for email: {email}")
            # Here you would typically add the email to your newsletter database
            flash('Thank you for subscribing to our newsletter!')
        else:
            flash('Please provide a valid email address.')
    return redirect(url_for('index'))

@app.route('/contact', methods=['POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')

        if name and email and message:
            logger.info(f"New contact form submission from {name} ({email})")
            # Here you would typically send the message to your email system
            flash('Thank you for your message. We will get back to you soon!')
        else:
            flash('Please fill in all fields.')
    return redirect(url_for('index'))

@app.route('/donate', methods=['POST'])
def donate():
    if request.method == 'POST':
        campaign = request.form.get('campaign')
        amount = request.form.get('amount')
        name = request.form.get('name')
        email = request.form.get('email')

        if campaign and amount and name and email:
            try:
                amount = float(amount)
                if amount <= 0:
                    raise ValueError("Amount must be positive")

                logger.info(f"New donation of ${amount} for campaign {campaign} from {name}")
                # Here you would typically process the donation through a payment gateway
                flash(f'Thank you for your generous donation of ${amount}!')
            except ValueError:
                flash('Please enter a valid donation amount.')
        else:
            flash('Please fill in all required fields.')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)